#include <iostream>
#include <GL/glut.h>
using namespace std;

int windowWidth = 500;
int windowHeight = 500;

// Function to initialize OpenGL settings
void init() {
    glClearColor(0.0f, 0.0f, 0.0f, 0.0f);  // Set background color to black
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, windowWidth, 0, windowHeight);
}

// Function to set a pixel with a given color
void setPixel(int x, int y, float* color) {
    glColor3fv(color);
    glBegin(GL_POINTS);
    glVertex2i(x, y);
    glEnd();
    glFlush();
}

void getPixel(int x, int y, float* color) {
    glReadPixels(x, y, 1, 1, GL_RGB, GL_FLOAT, color);
}

// Function to compare two colors
bool isSameColor(float* color1, float* color2) {
    return (color1[0] == color2[0] && color1[1] == color2[1] && color1[2] == color2[2]);
}

// 4-connected Boundary Fill algorithm
void boundaryFill4(int x, int y, float* fillColor, float* boundaryColor) {
    float currentColor[3];
    getPixel(x, y, currentColor);

    if (!isSameColor(currentColor, boundaryColor) && !isSameColor(currentColor, fillColor)) {
        setPixel(x, y, fillColor);
        boundaryFill4(x + 1, y, fillColor, boundaryColor);  // Right
        boundaryFill4(x - 1, y, fillColor, boundaryColor);  // Left
        boundaryFill4(x, y + 1, fillColor, boundaryColor);  // Up
        boundaryFill4(x, y - 1, fillColor, boundaryColor);  // Down
    }
}

// 8-connected Boundary Fill algorithm
void boundaryFill8(int x, int y, float* fillColor, float* boundaryColor) {
    float currentColor[3];
    getPixel(x, y, currentColor);

    if (!isSameColor(currentColor, boundaryColor) && !isSameColor(currentColor, fillColor)) {
        setPixel(x, y, fillColor);
        boundaryFill8(x + 1, y, fillColor, boundaryColor);  // Right
        boundaryFill8(x - 1, y, fillColor, boundaryColor);  // Left
        boundaryFill8(x, y + 1, fillColor, boundaryColor);  // Up
        boundaryFill8(x, y - 1, fillColor, boundaryColor);  // Down
        boundaryFill8(x + 1, y + 1, fillColor, boundaryColor);  // Diagonal Up-Right
        boundaryFill8(x - 1, y + 1, fillColor, boundaryColor);  // Diagonal Up-Left
        boundaryFill8(x + 1, y - 1, fillColor, boundaryColor);  // Diagonal Down-Right
        boundaryFill8(x - 1, y - 1, fillColor, boundaryColor);  // Diagonal Down-Left
    }
}

// 4-connected Flood Fill algorithm
void floodFill4(int x, int y, float* oldColor, float* newColor) {
    float color[3];
    getPixel(x, y, color);

    if (isSameColor(color, oldColor)) {
        setPixel(x, y, newColor);
        floodFill4(x + 1, y, oldColor, newColor);  // Right
        floodFill4(x - 1, y, oldColor, newColor);  // Left
        floodFill4(x, y + 1, oldColor, newColor);  // Up
        floodFill4(x, y - 1, oldColor, newColor);  // Down
    }
}

// 8-connected Flood Fill algorithm
void floodFill8(int x, int y, float* oldColor, float* newColor) {
    float color[3];
    getPixel(x, y, color);

    if (isSameColor(color, oldColor)) {
        setPixel(x, y, newColor);
        floodFill8(x + 1, y, oldColor, newColor);  // Right
        floodFill8(x - 1, y, oldColor, newColor);  // Left
        floodFill8(x, y + 1, oldColor, newColor);  // Up
        floodFill8(x, y - 1, oldColor, newColor);  // Down
        floodFill8(x + 1, y + 1, oldColor, newColor);  // Diagonal Up-Right
        floodFill8(x - 1, y + 1, oldColor, newColor);  // Diagonal Up-Left
        floodFill8(x + 1, y - 1, oldColor, newColor);  // Diagonal Down-Right
        floodFill8(x - 1, y - 1, oldColor, newColor);  // Diagonal Down-Left
    }
}

// Display function to draw boundary (rectangle) without applying fill automatically
void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_LINE_LOOP);
    glColor3f(0.0f, 0.0f, 1.0f);  // Boundary color
    glVertex2i(100, 100);
    glVertex2i(300, 100);
    glVertex2i(300, 250);
    glVertex2i(100, 250);
    glEnd();
    glFlush();
}

// Menu handler function
void menu(int choice) {
    float boundaryColor[3] = {0.0f, 0.0f, 1.0f};  // Boundary color (blue)
    float fillColor[3] = {1.0f, 0.0f, 0.0f};  // Fill color (red)
    float oldColor[3] = {0.0f, 0.0f, 0.0f};   // Background color (black)

    switch (choice) {
        case 1:
            // 4-connected Boundary Fill
            boundaryFill4(150, 150, fillColor, boundaryColor);
            break;
        case 2:
            // 8-connected Boundary Fill
            boundaryFill8(150, 150, fillColor, boundaryColor);
            break;
        case 3:
            // 4-connected Flood Fill
            floodFill4(150, 150, oldColor, fillColor);
            break;
        case 4:
            // 8-connected Flood Fill
            floodFill8(150, 150, oldColor, fillColor);
            break;
    }
    glutPostRedisplay();  // Redraw after filling
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE);
    glutInitWindowSize(windowWidth, windowHeight);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Boundary and Flood Fill - 4 & 8 connected");
    init();
    glutDisplayFunc(display);

    // Create menu for different fill options
    glutCreateMenu(menu);
    glutAddMenuEntry("Boundary Fill (4-connected)", 1);
    glutAddMenuEntry("Boundary Fill (8-connected)", 2);
    glutAddMenuEntry("Flood Fill (4-connected)", 3);
    glutAddMenuEntry("Flood Fill (8-connected)", 4);
    glutAttachMenu(GLUT_RIGHT_BUTTON);

    glutMainLoop();
    return 0;
}
