#include <GL/glut.h>

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // Draw vertical line of the plus operator
    glBegin(GL_LINES);
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glVertex2f(0.0f, -0.2f);     // Bottom point
    glVertex2f(0.0f, 0.2f);      // Top point
    glEnd();

    // Draw horizontal line of the plus operator
    glBegin(GL_LINES);
    glColor3f(1.0f, 1.0f, 1.0f); // White color
    glVertex2f(-0.2f, 0.0f);     // Left point
    glVertex2f(0.2f, 0.0f);      // Right point
    glEnd();

    // Draw a separate horizontal red line
    glBegin(GL_LINES);
    glColor3f(1.0f, 0.0f, 0.0f); // Red color
    glVertex2f(-0.7f, -0.3f);    // Left point
    glVertex2f(-0.5f, -0.3f);    // Right point
    glEnd();

    // Draw the asterisk (*)
    glBegin(GL_LINES);
    glColor3f(0.0f, 0.0f, 1.0f); // Blue color
    // First diagonal line
    glVertex2f(0.2f, 0.2f);      // Top-right point
    glVertex2f(-0.2f, -0.2f);    // Bottom-left point

    // Second diagonal line
    glVertex2f(-0.2f, 0.2f);     // Top-left point
    glVertex2f(0.2f, -0.2f);     // Bottom-right point
    glEnd();

    glFlush();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Plus and Horizontal Line");
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
