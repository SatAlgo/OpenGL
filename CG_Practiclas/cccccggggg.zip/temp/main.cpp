#include<GL/glut.h>
void displayMe(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_POLYGON);
        glVertex3f(100, 200, 00);
        glVertex3f(300, 60, 0);
        glVertex3f(300, 130, 00);
        glVertex3f(400, 150, 00);
    glEnd();
    glFlush();
}
void init() {
    glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(0, 500, 0, 500);
}
int main(int argc, char** argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("House Drawing using Bresenham's Algorithm");
    init();
    glutDisplayFunc(displayMe);
    glutMainLoop();
    return 0;
}
