#include <GL/glut.h>
#include <cmath>

// Function to draw a pixel at (x, y)
void drawPixel(int x, int y) {
    glBegin(GL_POINTS);
    glVertex2i(x, y);
    glEnd();
}

// Midpoint Circle Algorithm
void midpointCircle(int xc, int yc, int r) {
    int x = 0;
    int y = r;
    int P = 1 - r;

    // Initial point
    drawPixel(xc, yc + r);

    // Plot the initial point in each octant
    for (x = 0; x <= y; x++) {
        if (P < 0) {
            P = P + 2 * x + 3;
        } else {
            P = P + 2 * (x - y) + 5;
            y--;
        }

        // Plot points in each octant
        drawPixel(xc + x, yc + y);
        drawPixel(xc - x, yc + y);
        drawPixel(xc + x, yc - y);
        drawPixel(xc - x, yc - y);
        drawPixel(xc + y, yc + x);
        drawPixel(xc - y, yc + x);
        drawPixel(xc + y, yc - x);
        drawPixel(xc - y, yc - x);
    }
}

// Display function
void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0, 1.0, 1.0);  // Set color to white

    // Set point size to make lines thicker
    glPointSize(3.0);

    // Specify the circle parameters (center and radius)
    int xc = 200;
    int yc = 200;
    int radius = 100;

    // Call the midpoint circle algorithm
    midpointCircle(xc, yc, radius);

    glFlush();
}

// Initialize OpenGL
void init() {
    glClearColor(0.0, 0.0, 0.0, 0.0);  // Set clear color to black
    glOrtho(0, 400, 0, 400, 1, -1);        // Set the coordinate system
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(400, 400);
    glutCreateWindow("Thick Midpoint Circle Algorithm");

    init();
    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}

