#include <iostream>
#include <GL/glut.h>
#include <stack>

struct Point {
    int x, y;
};

void floodFill(int x, int y, int newColor, int oldColor);

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    // rectangle coordinates
    int top, left, bottom, right;
    top = left = 50;
    bottom = right = 300;

    // rectangle for display
    glBegin(GL_LINE_LOOP);
    glVertex2i(left, top);
    glVertex2i(right, top);
    glVertex2i(right, bottom);
    glVertex2i(left, bottom);
    glEnd();

    // filling start coordinates
    int x = 51;
    int y = 51;

    // new color to fill
    int newColor = 12;

    // old color to replace
    int oldColor = 0;

    // call for fill rectangle
    floodFill(x, y, newColor, oldColor);

    glFlush();
}

void floodFill(int x, int y, int newColor, int oldColor) {
    if (x < 0 || x >= glutGet(GLUT_WINDOW_WIDTH) || y < 0 || y >= glutGet(GLUT_WINDOW_HEIGHT)) {
        return;
    }

    GLubyte pixel[3];
    glReadPixels(x, glutGet(GLUT_WINDOW_HEIGHT) - y, 1, 1, GL_RGB, GL_UNSIGNED_BYTE, &pixel);

    if (pixel[0] != oldColor) {
        return;
    }

    std::stack<Point> points;
    points.push({x, y});

    while (!points.empty()) {
        Point current = points.top();
        points.pop();

        int cx = current.x;
        int cy = current.y;

        glColor3i(newColor, newColor, newColor);
        glBegin(GL_POINTS);
        glVertex2i(cx, glutGet(GLUT_WINDOW_HEIGHT) - cy);
        glEnd();
        glFlush();

        // Add neighboring pixels to the stack
        if (cx + 1 < glutGet(GLUT_WINDOW_WIDTH)) points.push({cx + 1, cy});
        if (cx - 1 >= 0) points.push({cx - 1, cy});
        if (cy + 1 < glutGet(GLUT_WINDOW_HEIGHT)) points.push({cx, cy + 1});
        if (cy - 1 >= 0) points.push({cx, cy - 1});
    }
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(400, 400);
    glutCreateWindow("Flood Fill");

    // Set background color to black
    glClearColor(0, 0, 0, 0);

    glOrtho(0, 400, 0, 400, -1, 1);

    glutDisplayFunc(display);

    glutMainLoop();

    return 0;
}
