#include <GL/glut.h>

void displayMe(void)
{
    glClear(GL_COLOR_BUFFER_BIT);
    glBegin(GL_POLYGON);
    glColor3f(1.0, 0.0, 0.0);

    glVertex2f(0.0f, 0.4f);     // Vertex 1 (top)
    glVertex2f(-0.35, 0.15);  // Vertex 2 (top-left)
    glVertex2f(-0.25, -0.3);  // Vertex 3 (bottom-left)
    glVertex2f(0.25, -0.3);   // Vertex 4 (bottom-right)
    glVertex2f(0.35, 0.15);   // Vertex 5 (top-right)

    glEnd();
    glFlush();
}

int main(int argc, char **argv)
{
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE);
    glutInitWindowSize(800, 800);
    glutInitWindowPosition(100, 100);
    glutCreateWindow("Pentagon");
    glutDisplayFunc(displayMe);
    glutMainLoop();

    return 0;
}
