#include <GL/glut.h>
#include <cmath>
#include <iostream>

double angle;
int default_x1 = 100, default_y1 = 100, default_x2 = 300, default_y2 = 300;

void drawLine(int x1, int y1, int x2, int y2) {
    glBegin(GL_LINES);
    glVertex2i(x1, y1);
    glVertex2i(x2, y2);
    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(1.0, 0.0, 0.0); // Red color

    drawLine(default_x1, default_y1, default_x2, default_y2);

    glFlush();
}

void reshape(int w, int h) {
    glViewport(0, 0, w, h);
    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    glOrtho(0, w, 0, h, 1, -1);
    glMatrixMode(GL_MODELVIEW);
}

void rotateLine() {
    double c = cos(angle * M_PI / 180.0);
    double s = sin(angle * M_PI / 180.0);

    int temp_x1 = default_x1 * c + default_y1 * s;
    int temp_y1 = -default_x1 * s + default_y1 * c;
    int temp_x2 = default_x2 * c + default_y2 * s;
    int temp_y2 = -default_x2 * s + default_y2 * c;

    default_x1 = temp_x1;
    default_y1 = temp_y1;
    default_x2 = temp_x2;
    default_y2 = temp_y2;
}

void keyboard(unsigned char key, int x, int y) {
    if (key == 'r' || key == 'R') {
        std::cout << "Enter rotation angle: ";
        std::cin >> angle;
        rotateLine();
        glutPostRedisplay();
    }
}

int main(int argc, char** argv) {
    std::cout << "Default coordinates of line: (100, 100) to (300, 300)\n";
    std::cout << "Enter rotation angle: ";
    std::cin >> angle;

    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_SINGLE | GLUT_RGB);
    glutInitWindowSize(500, 500);
    glutCreateWindow("Rotating Line using GLUT");

    glOrtho(0, 500, 0, 500, 1, -1);

    glutDisplayFunc(display);
    glutReshapeFunc(reshape);
    glutKeyboardFunc(keyboard);

    glutMainLoop();

    return 0;
}
