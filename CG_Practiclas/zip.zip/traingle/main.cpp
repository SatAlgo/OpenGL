#include <GL/glut.h>

void display() {
    glClear(GL_COLOR_BUFFER_BIT);

    glBegin(GL_TRIANGLES); // Begin drawing a triangle
    glColor3f(0.0, 1.0, 0.0); // Set color to green (R, G, B)
    glVertex2f(0.0, 0.5);    // Define vertices (top)
    glVertex2f(-0.5, -0.5);  // (bottom-left)
    glVertex2f(0.5, -0.5);   //  (bottom-right)
    glEnd(); // End drawing the triangle

    glFlush(); // Flush the OpenGL buffer
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitwind
    glutCreateWindow("OpenGL Triangle");
    glutDisplayFunc(display);
    glutMainLoop();
    return 0;
}
