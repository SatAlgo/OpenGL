#include <GL/glut.h>

void drawCuboid() {
    glBegin(GL_QUADS);

    // Top face
    glColor3f(1.0f, 0.0f, 0.0f);  // Red
    glVertex3f(-1.0f, 1.0f, -1.0f);  // Front-left
    glVertex3f(1.0f, 1.0f, -1.0f);   // Front-right
    glVertex3f(1.0f, 1.0f, 1.0f);    // Back-right
    glVertex3f(-1.0f, 1.0f, 1.0f);   // Back-left

    // Front face
    glColor3f(0.0f, 0.0f, 1.0f);  // Blue
    glVertex3f(-1.0f, -1.0f, 1.0f);  // Bottom-left
    glVertex3f(1.0f, -1.0f, 1.0f);   // Bottom-right
    glVertex3f(1.0f, 1.0f, 1.0f);    // Top-right
    glVertex3f(-1.0f, 1.0f, 1.0f);   // Top-left

    // Right face
    glColor3f(0.0f, 1.0f, 0.0f);  // Green
    glVertex3f(1.0f, -1.0f, 1.0f);   // Bottom-front
    glVertex3f(1.0f, -1.0f, -1.0f);  // Bottom-back
    glVertex3f(1.0f, 1.0f, -1.0f);   // Top-back
    glVertex3f(1.0f, 1.0f, 1.0f);    // Top-front

    glEnd();
}

void display() {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glLoadIdentity();
    glTranslatef(0.0f, 0.0f, -5.0f);

    drawCuboid();

    glutSwapBuffers();
}

int main(int argc, char** argv) {
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);
    glutInitWindowSize(800, 600);
    glutCreateWindow("Cuboid");

    glEnable(GL_DEPTH_TEST);

    glutDisplayFunc(display);
    glutMainLoop();

    return 0;
}
